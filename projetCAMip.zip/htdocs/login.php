<?php 
session_start(); 
include("const.php");
?>
<html>
	<head>
		<link rel="stylesheet" href="/css/bootstrap.min.css">
		<link rel="stylesheet" href="/css/login.css">
		<script src="/js/bootstrap.min.js"></script>
	
    <title>RIL/RISR TV  !</title>
            <META content="text/html"; charset="UTF-8"; http-equiv=Content-Type>
            <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
            <META HTTP-EQUIV="Expires" CONTENT="-1">
	</head>
<body>
<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Sign In</h3>
			</div>
			<div class="card-body">
				<form action="#" method="POST">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="username" id='login' name='login'>
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="password" id='mdp' name='mdp'>
					</div>
					<div class="form-group">
						<input type="submit" value="Login" class="btn float-right login_btn" id='button' name='button'>
					</div>
				</form>
			</div>
			<?php	
				if (isset($_GET["m"])) {
					switch ($_GET["m"]) {
					case 0:
						echo '<div class="alert alert-danger" style="text-align:center" role="alert">Acces non autorisé !</div>';
						break;
					case 1:
						echo '<div class="alert alert-danger" style="text-align:center" role="alert">Mauvais login !</div>';
						break;
					case 2:
						echo '<div class="alert alert-danger" style="text-align:center" role="alert">Mauvais mot de passe !</div>';
						break;
					case 3:
						echo '<div class="alert alert-danger" style="text-align:center" role="alert">Impossible de communiquer avec la caméra principale !</div>';
						break;
					case 10:
						echo '<div class="alert alert-danger" style="text-align:center" role="alert">Vous avez été déconnecté !</div>';
						break;
					}
				}
			?>
		</div>
	</div>
</div>
</body>
</html>

<?php

if (isset($_POST['button'])) {

	$curl_handle=curl_init();
	curl_setopt($curl_handle, CURLOPT_URL,MAIN_USER_LIST);
	curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
	$file = curl_exec($curl_handle);
	$httpcode = curl_getinfo($curl_handle, CURLINFO_HTTP_CODE);  
	curl_close($curl_handle);
	
    if($httpcode>=200 && $httpcode<300){
	
	$my_array = preg_split('/\s+/', $file, -1, PREG_SPLIT_NO_EMPTY);
	
		if (in_array("UserName=".$_POST['login'], $my_array)){
			$key = array_search("UserName=".$_POST['login'], $my_array);
			
			if ($my_array[$key+1] == "UserPassword=".$_POST['mdp']){
				$_SESSION["login"] = $_POST['login'];
				$_SESSION["Privilege"] = $my_array[$key+2];
				header("Location: /interface.php");
				die();
			}
			else{
				header("Location: /login.php?m=2");
			}
		}
		else {
			header("Location: /login.php?m=1");
		}
		
	}
	else {
		header("Location: /login.php?m=3");
	}
}
?>
























