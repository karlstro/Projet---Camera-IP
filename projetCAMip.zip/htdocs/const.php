<?php
define("NB_CAMERA", "1"); 	//Défini le nombre de caméra actives
define("MAIN_CAMERA_IP", "http://192.168.104.1:8888");		//Défini l'ip de la camera principale
define("MAIN_USER_LIST", "http://admin@192.168.104.1:8888/userlist.cgi");		//Définir l'userlist de la caméra principale
define("MAIN_CAM_INFO" , "http://admin@192.168.104.1:8888/image.cgi");		//définir les informations pour la camera
define("MAIN_CAM_ID", "SUPER CAM PRINCIPALE");		//Nom de la caméra principale
?>
