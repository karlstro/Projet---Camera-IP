<?php 
session_start();
include("const.php");
if (!isset($_SESSION['login'])) {
	header("Location: /login.php?m=0");
}
?>
<html>
	<head>
		<link rel="stylesheet" href="/css/bootstrap.min.css">
		<script src="/js/bootstrap.min.js"></script>
	
    <title>RIL/RISR TV  !</title>
            <META content="text/html"; charset="UTF-8"; http-equiv=Content-Type>
            <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
            <META HTTP-EQUIV="Expires" CONTENT="-1">
    
		<style type="text/css">
			table, tr, td {
				border: 1px solid black;
				text-align:center;
				background-color:RGBa(74,98,107,0.2);
				color:white;
			}
			
			table{
				width:100%;
			}
			.content {
		        width:50%;
				margin-left:auto;
				margin-right:auto;
			}
			body{
				background-image: url("/img/fond.jpg");
				background-size: cover;
			}
			.informations{
				/*visibility:collapse*/
			}
		</style>
	</head>
    <body>
	<div class="content">
        <table>
			<tr>
				<td>
					<img src="/img/dlink_logo.jpg" width=50%>
					<?php echo "<br>Connecté en tant que : ".$_SESSION["login"]; ?>
				</td>
				<td colspan=2>
						<button type="button" class="btn btn-warning" onclick="window.location.href = 'interface.php';">Retour</button>
				</td>
			</tr>
			<tr>
				<td>
					Gestion de l'image
				</td>
				<td>
					<form action='' method="post" id="form_light" name="form_light">
					Luminosité : <input type="number" min="1" max="128" id="Brightness" name="Brightness" class="form-control-sm"><br/>
					Contraste : <input type="number" min="1" max="128" id="Contrast" name="Contrast" class="form-control-sm"><br/>
					Saturation : <input type="number" min="1" max="128" id="Saturation" name="Saturation" class="form-control-sm"></td><td>
					<button type="submit" name="light_submit" id="light_submit" onclick="return Light_edit();" class="btn btn-primary">Valider</button>
					</form>
				</td>
			</tr>
			<tr>
				<td>
				Creation d'utilisateurs
				</td>
				<td>
					<form action='' method="post" id="form_add_user" name="form_add_user">
						Login : <input type="text" pattern=".{4,12}" id="login" name="login" class="form-control-sm"><br/>
						Mot de passe : <input type="text" pattern=".{4,12}" id="mdp" name="mdp" class="form-control-sm"><br/>
						Niveau privilège : <input type="number" min="0" max="1" id="privilege" name="privilege" class="form-control-sm"></td><td>
					<button type="submit" name="user_submit" id="user_submit" onclick="return user_add();" class="btn btn-primary">Creer</button>
					</form>
				</td>
			</tr>
		</table>
		<table>
			<tr>
				<td colspan=3>
					LISTE DES UTILISATEURS
				</td>
			</tr>
			<tr>
				<th>
					Nom
				</th>
				<th>
					Privilege
				</th>
				<th>
					Action
				</th>
			</tr>
			<?php
				$curl_handle=curl_init();
				curl_setopt($curl_handle, CURLOPT_URL,MAIN_USER_LIST);
				curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
				curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
				$file = curl_exec($curl_handle);
				$httpcode = curl_getinfo($curl_handle, CURLINFO_HTTP_CODE);  
				curl_close($curl_handle);
				$my_array = preg_split('/\s+/', $file, -1, PREG_SPLIT_NO_EMPTY);
				
				for ($i = 0; $i <= count($a+1); $i=$i+3) {
					echo "<tr><td>".$my_array[$i]."</td><td>".$my_array[$i+2]."</td>";
					echo "<td><button class='btn btn-danger' id='btn_del".$my_array[$i]."' name='btn_del".$my_array[$i]."'>Supprimer</button></td></tr>";
				}
			
			
			?>
		</table>
		<table>
			<tr>
				<td>
				
			<tr class="informations">
				<td colspan=4>
				Aperçu de la réponse :<br/>
					<iframe src='' name='frame_validation'></iframe>
				</td>
			</tr>
			<tr>
				<td>
					<div <?php if($_SESSION["Privilege"] == "UserPrivilege=1"){echo "style=visibility:hidden";}?> > 
						<button type="button" class="btn btn-warning" onclick="window.location.href = 'http://192.168.104.1:8888/';">Panneau Admin Caméra</button>
					</div>
				</td>
			</tr>
		</table>
	</div>
		<?php ?>
		<script language="Javascript">
			function Light_edit()
			{
				var lum = document.getElementById("Brightness").value;
				var con = document.getElementById("Contrast").value;
				var sat = document.getElementById("Saturation").value;
				<? echo 'document.form_light.action = "'.MAIN_CAMERA_IP.'/image.cgi?BrightnessControl="+ lum +" &ContrastControl="+ con +" &SaturationControl="+ sat +"&ConfigReboot=No";' ?>
				document.Form1.target = "form_light";
				document.Form1.submit();
			}
			function user_add()
			{
				var lum = document.getElementById("login").value;
				var con = document.getElementById("mdp").value;
				var sat = document.getElementById("privilege").value;
				<? echo 'document.form_add_user.action = "'.MAIN_CAMERA_IP.'/userlist.cgi?BrightnessControl="+ login +" &ContrastControl="+ mdp +" &SaturationControl="+ privilege +"&UserAdd=Yes";' ?>
				document.form_add_user.target = "form_add_user";
				document.form_add_user.submit();
			}
		</script>
    </body>
</html>