<?php 
session_start();
include("const.php");
if (!isset($_SESSION['login'])) {
	header("Location: /login.php?m=0");
}
$curl_handle=curl_init();
curl_setopt($curl_handle, CURLOPT_URL,MAIN_CAM_INFO);
curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Your application name');
$file = curl_exec($curl_handle);
curl_close($curl_handle);
$my_array = preg_split('/\s+/', $file, -1, PREG_SPLIT_NO_EMPTY);

if (isset($_POST['btn_stop_rec'])){
	$_session["rec"] = 0;
	echo $ssh->exec('killall vlc');
}
if (isset($_POST['btn_rec'])){
	$_session["rec"] = 1;
	echo $ssh->exec('cvlc http://192.168.104.1:8888/video/mjpg.cgi --sout="#duplicate{dst=std{access=file,mux=ts,dst=/home/camera/FTP/videos/'.date("M,d,Y-h:i:s").'.mp4"');
}
?>
<html>
	<head>
		<link rel="stylesheet" href="/css/bootstrap.min.css">
		<script src="/js/bootstrap.min.js"></script>
	
    <title>RIL/RISR TV  !</title>
            <META content="text/html"; charset="UTF-8"; http-equiv=Content-Type>
            <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
            <META HTTP-EQUIV="Expires" CONTENT="-1">
    
		<style type="text/css">
			table, tr, td {
				border: 1px solid black;
				text-align:center;
				background-color:RGBa(74,98,107,0.2);
				color:white;
			}
			a {
				color:#45c845;
				font-weight:bold;
			}
			.tablelist{
				width:100%;
			}
			.content {
		        width:50%;
				margin-left:auto;
				margin-right:auto;
			}
			body{
				background-image: url("/img/fond.jpg");
				background-size: cover;
			}
			.informations{
				visibility:collapse
			}
		</style>
	</head>
    <body>
	<div class="content">
        <table>
			<tr>
				<td>
					<img src="/img/dlink_logo.jpg" width=50%>
					<?php echo "<br>Connecté en tant que : <strong>".$_SESSION["login"]."</strong>"; ?>
				</td>
				<td colspan=3>
				<h2><?php echo MAIN_CAM_ID; ?></h2>
				</td>
			</tr>
			<tr>
				<td>
				<form name="Form1" method="post">
					<div>	
						FrameRate :<br/>
						<button type="submit" <?php echo (in_array("FrameRate=5", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=FrameRate value="5" onclick="return image();">X5</button>
						<button type="submit" <?php echo (in_array("FrameRate=20", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=FrameRate value="20" onclick="return image();">X20</button>
					</div>
					<hr>
					<div>
						Resolutions :<br/>
						<button type="submit" <?php echo (in_array("VideoResolution=0", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=VideoResolution value="0" onclick="return image();">160x120</button>
						<button type="submit" <?php echo (in_array("VideoResolution=1", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=VideoResolution value="1" onclick="return image();">320x240</button>
						<button type="submit" <?php echo (in_array("VideoResolution=2", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=VideoResolution value="2" onclick="return image();">640x480</button>
					</div>
					<hr>
					<div>
						Compression :<br/>
						<button type="submit" <?php echo (in_array("CompressionRate=0", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=CompressionRate value="0" onclick="return image();">Very Low</button>
						<button type="submit" <?php echo (in_array("CompressionRate=1", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=CompressionRate value="1" onclick="return image();">Low</button>
						<button type="submit" <?php echo (in_array("CompressionRate=2", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=CompressionRate value="2" onclick="return image();">Medium</button>
						<button type="submit" <?php echo (in_array("CompressionRate=3", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=CompressionRate value="3" onclick="return image();">High</button>
						<button type="submit" <?php echo (in_array("CompressionRate=4", $my_array) ?  'class="btn btn-primary btn-sm"' : 'class="btn btn-secondary btn-sm"') ?> name=CompressionRate value="4" onclick="return image();">Very High</button>
					</div>
					<hr>
					<div>
						Zoom :<br/>
						<button type="button" class="btn btn-primary btn-sm" id="btn_1" onclick="return zoom1();">x1</button>
						<button type="button" class="btn btn-secondary btn-sm" id="btn_2" onclick="return zoom2();">x2</button>
						<button type="button" class="btn btn-secondary btn-sm" id="btn_3" onclick="return zoom3();">x3</button>
					</div>
				</form>
					<hr>
					<div> 
						<form action="interface.php" method="post">
						<?php 
						if(isset($_session["rec"])){
							if($_session["rec"] == 1){
								echo "<button type='submit' id='btn_stop_rec' name='btn_stop_rec' class='btn btn-danger'>Arrêter l enregistrement</button>";
							}
							else{
								echo "<button type='submit' id='btn_rec' name='btn_rec' class='btn btn-info'>Démarrer l enregistrement</button>";
							}
						}
						?>
						</form>
					</div>
					<hr>
					<div <?php if($_SESSION["Privilege"] == "UserPrivilege=0"){echo "style=visibility:hidden";}?>>
						<button type="submit" class="btn btn-danger" onclick="return reset();">Reboot</button>
					</div>
					<hr>
					<div <?php if($_SESSION["Privilege"] == "UserPrivilege=0"){echo "style=visibility:hidden";}?> > 
						<button type="button" class="btn btn-warning" onclick="window.location.href = 'admin.php';">Panneau Admin</button>
					</div>
					<hr>
					<div>
						<button type="button" class="btn btn-warning" onclick="window.location.href = 'close.php';">Deconnexion</button>
					</div>
				</td>
				<td colspan=3>
					<div style="overflow: hidden;">
						<?php echo "<img src='".MAIN_CAMERA_STREAM."' id='frame_video' name='frame_video' alt='Chargement...' style='transform-origin: center center;' width='100%'>"; ?>
					</div>
				</td>
			</tr>
			<tr class="informations">
				<td colspan=4>
					<iframe src='' name='frame_validation'></iframe>
				</td>
			</tr>
		</table>
		<table class="tablelist">
			<tr>
				<th>
					name
				</th>
				<th>
					type
				</th>
				<th>
					date
				</th>
				<th>
					link
				</th>
			</tr>
			<?php
			$dir = "/var/www/html/projetCAMip/videos/";
			/*$files = glob($dir."*.jpeg");*/
			$files = glob($dir."*");
			foreach ($files as $filename) {
				echo "<tr>";
				echo "<td>".basename($filename)."</td><td>".filetype($filename)."</td><td>".date("F d Y H:i:s.", filemtime($filename))."</td><td><a href='/videos/".basename($filename)."'>Download</a></td></tr>";
			}
			?>
		</table>
		</div>
		
		<script language="Javascript">
			function image()
			{
				<?php echo 'document.Form1.action = "'.MAIN_CAMERA_IP.'/image.cgi?ConfigReboot=No";'; ?>
				document.Form1.target = "frame_validation";
				document.Form1.submit();
				return true;
			}
			function reset()
			{
				<?php echo 'document.Form1.action = "'.MAIN_CAMERA_IP.'/reset.cgi?Reset=Yes";' ?>
				document.Form1.target = "frame_validation";
				document.Form1.submit();
				return true;
			}
			function zoom1()
			{
				var item = document.getElementById("frame_video")
				item.style.transform = "scale(1)";
				document.getElementById("btn_1").classList.remove('btn-secondary');
				document.getElementById("btn_2").classList.remove('btn-primary');
				document.getElementById("btn_3").classList.remove('btn-primary');
				document.getElementById("btn_1").classList.add('btn-primary');
				document.getElementById("btn_2").classList.add('btn-secondary');
				document.getElementById("btn_3").classList.add('btn-secondary');
			}
			function zoom2()
			{
				var item = document.getElementById("frame_video")
				item.style.transform = "scale(2)";
				document.getElementById("btn_1").classList.remove('btn-primary');
				document.getElementById("btn_2").classList.remove('btn-secondary');
				document.getElementById("btn_3").classList.remove('btn-primary');
				document.getElementById("btn_1").classList.add('btn-secondary');
				document.getElementById("btn_2").classList.add('btn-primary');
				document.getElementById("btn_3").classList.add('btn-secondary');
			}
			function zoom3()
			{
				var item = document.getElementById("frame_video")
				item.style.transform = "scale(3)";
				document.getElementById("btn_1").classList.remove('btn-primary');
				document.getElementById("btn_2").classList.remove('btn-primary');
				document.getElementById("btn_3").classList.remove('btn-secondary');
				document.getElementById("btn_1").classList.add('btn-secondary');
				document.getElementById("btn_2").classList.add('btn-secondary');
				document.getElementById("btn_3").classList.add('btn-primary');
			}
		</script>
    </body>
</html>