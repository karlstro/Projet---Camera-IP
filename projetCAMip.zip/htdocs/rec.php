<?php
set_include_path('C:/xampp/htdocs/projetCAMip/ssh');
include('ssh/Net/SSH2.php');

$ssh = new Net_SSH2('192.168.0.1');
if (!$ssh->login('pi', 'raspberry')) {
    exit('Login Failed');
}

/*echo $ssh->exec('cvlc -vvv http://admin@192.168.0.1:8888/video.cgi --sout=#transcode{vcodec=h264,vb=1024,scale=1}:duplicate{dst=std{access=http,mux=mjpeg,dst="test10.mjpeg"}} --run-time=10000');*/
echo $ssh->exec('cvlc http://192.168.104.1:8888/video/mjpg.cgi --sout="#duplicate{dst=std{access=file,mux=ts,dst=/home/camera/FTP/videos/'.date("M,d,Y-h:i:s").'.mp4"');
?>