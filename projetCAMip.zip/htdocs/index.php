<?php
//Nothing to do here...
header("Location: /login.php");
?>