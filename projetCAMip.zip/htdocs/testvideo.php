<img src="/img/dlink_logo.jpg" width='100%'>

IMG :<br/>
<div style="overflow: hidden;">
	<img src='http://admin@192.168.104.1:8888/video.cgi' width='100%'>
</div>

<br/><br/>IFRAME:<br/>
<iframe src="http://admin@192.168.104.1:8888/video.cgi"width="640" height="480" class="smart_sizing_iframe noresize" frameborder="0" scrolling="no" ></iframe>